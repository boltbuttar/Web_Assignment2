const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { verifyToken } = require('../middleware/authMiddleware');
const Course = require('../models/Course');
const Student = require('../models/Student');

// Dashboard page route (protected)
router.get('/dashboard', verifyToken, async (req, res) => {
    try {
        // Get stats
        const [totalCourses, totalStudents] = await Promise.all([
            Course.countDocuments(),
            Student.countDocuments()
        ]);

        // Get recent courses
        const recentCourses = await Course.find()
            .sort({ createdAt: -1 })
            .limit(5);

        // Get recent students
        const recentStudents = await Student.find()
            .sort({ createdAt: -1 })
            .limit(5);

        // Calculate department stats
        const courses = await Course.find();
        const departmentStats = courses.reduce((acc, course) => {
            acc[course.department] = (acc[course.department] || 0) + 1;
            return acc;
        }, {});

        res.render('admin/dashboard', {
            title: 'Admin Dashboard',
            admin: {
                name: req.user.username || 'Administrator'
            },
            stats: {
                totalCourses,
                totalStudents,
                totalDepartments: Object.keys(departmentStats).length,
                departmentStats
            },
            recentCourses,
            recentStudents
        });
    } catch (error) {
        console.error('Dashboard Error:', error);
        res.status(500).render('error', {
            message: 'Error loading dashboard',
            error: { status: 500 }
        });
    }
});

// API routes (all protected)
router.get('/courses', verifyToken, adminController.getCourses);
router.post('/courses', verifyToken, adminController.addCourse);
router.put('/courses/:id', verifyToken, adminController.editCourse);
router.delete('/courses/:id', verifyToken, adminController.deleteCourse);

router.get('/students', verifyToken, adminController.getStudents);
router.post('/students', verifyToken, adminController.addStudent);
router.put('/students/:id', verifyToken, adminController.editStudent);
router.delete('/students/:id', verifyToken, adminController.deleteStudent);

router.get('/reports', verifyToken, adminController.generateReports);

module.exports = router;
