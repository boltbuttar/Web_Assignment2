const express = require('express');
const Student = require('../models/Student');
const Course = require('../models/Course');
const router = express.Router();

// Get All Courses
router.get('/', async (req, res) => {
    const courses = await Course.find();
    res.json(courses);
});

// Register for a course
router.post('/register', async (req, res) => {
    const { rollNumber, courseCode } = req.body;

    const student = await Student.findOne({ rollNumber });
    const course = await Course.findOne({ courseCode });

    if (!student || !course) return res.status(404).json({ message: "❌ Invalid student or course" });

    if (course.seatsAvailable <= 0) return res.status(400).json({ message: "❌ No seats available" });

    student.courses.push(course._id);
    course.seatsAvailable -= 1;

    await student.save();
    await course.save();

    res.json({ message: "✅ Course registered successfully", student });
});

module.exports = router;
