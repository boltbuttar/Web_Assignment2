const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

// ✅ Frontend Login Pages
router.get("/student/login", (req, res) => {
    res.render("auth/studentLogin", { title: "Student Login" });
});

router.get("/admin/login", (req, res) => {
    res.render("auth/adminLogin", { title: "Admin Login" });
});

// Add these routes to fix 404 errors
router.get("/student", (req, res) => {
    res.redirect("/auth/student/login");
});

router.get("/admin", (req, res) => {
    res.redirect("/auth/admin/login");
});

// ✅ API Endpoints
router.post("/student/login", authController.studentLogin);
router.post("/admin/login", authController.adminLogin);

module.exports = router;
