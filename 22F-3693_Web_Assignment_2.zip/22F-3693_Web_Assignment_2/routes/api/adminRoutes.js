const express = require("express");
const router = express.Router();
const adminController = require("../../controllers/adminController");
const { verifyToken } = require("../../middleware/authMiddleware");

// API Routes for Admin
// Course Management
router.get("/courses", verifyToken, adminController.getCourses);
router.post("/courses", verifyToken, adminController.addCourse);
router.put("/courses/:id", verifyToken, adminController.editCourse);
router.delete("/courses/:id", verifyToken, adminController.deleteCourse);

// Student Management
router.get("/students", verifyToken, adminController.getStudents);

// Reports
router.get("/reports/:type", verifyToken, adminController.generateReports);

module.exports = router;
