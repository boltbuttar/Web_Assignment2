const express = require("express");
const router = express.Router();
const studentController = require("../controllers/studentController");
const { verifyToken } = require("../middleware/authMiddleware");

// ✅ Dashboard
router.get("/dashboard", verifyToken, studentController.getStudentDashboard);

// ✅ Schedule
router.get("/schedule", verifyToken, studentController.getSchedule);

// ✅ Available Courses
router.get("/courses", verifyToken, studentController.getAvailableCourses);

// ✅ Register for a Course
router.post("/register", verifyToken, studentController.registerCourse);

// ✅ Drop a Course
router.post("/drop", verifyToken, studentController.dropCourse);

// ✅ Filter Courses
router.get("/filter-courses", verifyToken, studentController.filterCourses);

// ✅ Check Prerequisites
router.post("/check-prerequisites", verifyToken, studentController.checkPrerequisites);

module.exports = router;
