const jwt = require("jsonwebtoken");

// Verify JWT Token
const verifyToken = (req, res, next) => {
    try {
        // For testing: Allow direct access to admin dashboard with test credentials
        if (req.originalUrl === '/admin/dashboard' && req.query.test === 'true') {
            req.user = { role: 'admin', username: 'Test Admin' };
            return next();
        }

        // Get token from Authorization header or cookie
        let token = null;
        
        // Check Authorization header
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.split(' ')[1];
        }
        
        // Check cookies
        if (!token && req.cookies && req.cookies.adminToken) {
            token = req.cookies.adminToken;
        }
        
        if (!token) {
            // For API routes, return JSON response
            if (req.xhr || req.path.startsWith('/api/')) {
                return res.status(401).json({ 
                    success: false, 
                    message: "Authentication required" 
                });
            }
            // For dashboard route, redirect to login
            return res.redirect('/auth/admin/login');
        }
        
        // Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET || "your-secret-key");
        
        // Add user info to request
        req.user = decoded;
        
        next();
    } catch (error) {
        console.error("Token verification error:", error.message);
        
        // For API routes, return JSON response
        if (req.xhr || req.path.startsWith('/api/')) {
            return res.status(401).json({ 
                success: false, 
                message: "Invalid or expired token" 
            });
        }
        // For dashboard route, redirect to login
        return res.redirect('/auth/admin/login');
    }
};

// Verify admin role
const verifyAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({ 
            success: false, 
            message: "Admin access required" 
        });
    }
};

module.exports = { verifyToken, verifyAdmin };
