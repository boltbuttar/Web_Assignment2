async function login() {
    const rollNumber = document.getElementById("rollNumber").value;

    const response = await fetch('/api/students/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rollNumber })
    });

    const data = await response.json();
    alert(data.message);
}

async function fetchCourses() {
    const response = await fetch('/api/courses');
    const courses = await response.json();

    const courseList = document.getElementById("courseList");
    courseList.innerHTML = courses.map(course => `<li>${course.courseName}</li>`).join('');
}

fetchCourses();

async function fetchSchedule() {
    const rollNumber = document.getElementById("rollNumber").value;
    const response = await fetch(`/api/students/${rollNumber}/schedule`);
    const courses = await response.json();

    let scheduleHTML = "<h2>Your Weekly Schedule</h2>";
    scheduleHTML += "<ul>";
    courses.forEach(course => {
        scheduleHTML += `<li>${course.courseName} - ${course.schedule}</li>`;
    });
    scheduleHTML += "</ul>";

    document.getElementById("schedule").innerHTML = scheduleHTML;
}
async function filterCourses() {
    const department = document.getElementById("departmentFilter").value;
    const response = await fetch(`/api/courses/search?department=${department}`);
    const courses = await response.json();

    let courseListHTML = "<h2>Filtered Courses</h2><ul>";
    courses.forEach(course => {
        courseListHTML += `<li>${course.courseName} (${course.courseCode})</li>`;
    });
    courseListHTML += "</ul>";

    document.getElementById("filteredCourses").innerHTML = courseListHTML;
}
async function addCourse() {
    const courseCode = document.getElementById("courseCode").value;
    const courseName = document.getElementById("courseName").value;
    const department = document.getElementById("courseDept").value;
    const schedule = document.getElementById("courseSchedule").value;
    const seatsAvailable = document.getElementById("courseSeats").value;

    const response = await fetch('/api/admins/add-course', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseCode, courseName, department, schedule, seatsAvailable })
    });

    const data = await response.json();
    alert(data.message);
}

async function login() {
    const rollNumber = document.getElementById("rollNumber").value;

    const response = await fetch('/api/students/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rollNumber })
    });

    const data = await response.json();
    alert(data.message);
}

async function fetchCourses() {
    const response = await fetch('/api/courses');
    const courses = await response.json();

    const courseList = document.getElementById("courseList");
    courseList.innerHTML = courses.map(course => `<li>${course.courseName} - ${course.schedule}</li>`).join('');
}

fetchCourses();
