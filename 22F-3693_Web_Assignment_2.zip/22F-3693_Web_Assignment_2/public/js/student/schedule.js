document.addEventListener("DOMContentLoaded", () => {
    fetchCourses();
});

async function fetchCourses() {
    const response = await fetch("/api/student/courses", {
        headers: { "Authorization": localStorage.getItem("token") }
    });

    const courses = await response.json();
    displayCourses(courses);
}

function displayCourses(courses) {
    const courseList = document.getElementById("courseList");
    courseList.innerHTML = "";

    courses.forEach(course => {
        const div = document.createElement("div");
        div.className = "course";
        div.innerHTML = `<strong>${course.title}</strong> (${course.code}) 
                         <button onclick="registerCourse('${course._id}')">Register</button>`;
        courseList.appendChild(div);
    });
}

async function registerCourse(courseId) {
    const response = await fetch("/api/student/register", {
        method: "POST",
        headers: { 
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem("token")
        },
        body: JSON.stringify({ courseId })
    });

    const data = await response.json();
    if (response.ok) {
        alert("Course registered!");
        updateSchedule();
    } else {
        alert(data.message);
    }
}

function filterCourses() {
    const query = document.getElementById("search").value.toLowerCase();
    const courses = document.querySelectorAll(".course");
    courses.forEach(course => {
        if (course.innerText.toLowerCase().includes(query)) {
            course.style.display = "block";
        } else {
            course.style.display = "none";
        }
    });
}

const socket = io();

function joinCourseRoom(courseId) {
    socket.emit("joinCourse", courseId);
}

socket.on("seatUpdate", (data) => {
    alert(`Seats updated for course: ${data.courseId}. Remaining seats: ${data.seats}`);
});

