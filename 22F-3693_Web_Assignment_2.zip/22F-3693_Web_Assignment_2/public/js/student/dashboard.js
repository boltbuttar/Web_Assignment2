// Global variables
let availableCourses = [];
let registeredCourses = [];
let departments = new Set();
let currentlyViewingCourse = null;
const socket = io();

// Functions to get the token
function getToken() {
    return localStorage.getItem('token');
}

document.addEventListener("DOMContentLoaded", () => {
    // Get student ID from the page data
    const studentId = document.getElementById('student-dashboard').dataset.studentId;
    
    // Initialize Socket.io connection
    socket.emit('joinStudentDashboard', studentId);
    
    // Load data when page loads
    loadRegisteredCourses();
    fetchAvailableCourses();
    
    // Set up tab navigation
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const tabId = this.getAttribute('onclick').match(/openTab\('(.+?)'\)/)[1];
            openTab(tabId);
        });
    });
    
    // Set up socket event listeners
    socket.on('courseUpdated', function(data) {
        // Refresh course data
        fetchAvailableCourses();
        loadRegisteredCourses();
    });
    
    // Initially show schedule tab
    openTab('schedule');
});

// Tab Navigation
function setupTabNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get the tab ID from the onclick attribute
            const onclickAttr = this.getAttribute('onclick');
            if (onclickAttr && onclickAttr.includes('openTab')) {
                const tabId = onclickAttr.match(/'([^']+)'/)[1];
                openTab(tabId);
                
                // Update active class on nav links
                navLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
}

// Open Tab Function
function openTab(tabId) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show the selected tab
    const selectedTab = document.getElementById(tabId);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
}

// Set up filter listeners
function setupFilterListeners() {
    // Department filter
    const departmentFilter = document.getElementById('department-filter');
    if (departmentFilter) {
        departmentFilter.addEventListener('change', filterCourses);
    }
    
    // Level filter
    const levelFilter = document.getElementById('level-filter');
    if (levelFilter) {
        levelFilter.addEventListener('change', filterCourses);
    }
    
    // Day filter
    const dayFilter = document.getElementById('day-filter');
    if (dayFilter) {
        dayFilter.addEventListener('change', filterCourses);
    }
    
    // Time filter
    const timeFilter = document.getElementById('time-filter');
    if (timeFilter) {
        timeFilter.addEventListener('change', filterCourses);
    }
    
    // Search filter
    const searchFilter = document.getElementById('search-filter');
    if (searchFilter) {
        searchFilter.addEventListener('input', filterCourses);
    }
    
    // Clear filters
    const clearFilters = document.getElementById('clear-filters');
    if (clearFilters) {
        clearFilters.addEventListener('click', clearAllFilters);
    }
}

// Clear all filters
function clearAllFilters() {
    document.getElementById('department-filter').value = '';
    document.getElementById('level-filter').value = '';
    document.getElementById('day-filter').value = '';
    document.getElementById('time-filter').value = '';
    document.getElementById('search-filter').value = '';
    
    filterCourses();
}

// Initialize Calendar Grid
function initializeCalendarGrid() {
    const calendarGrid = document.getElementById('calendar-grid');
    if (!calendarGrid) return;
    
    calendarGrid.innerHTML = '';
    
    // Time slots from 8 AM to 8 PM
    const timeSlots = [];
    for (let hour = 8; hour <= 20; hour++) {
        const displayHour = hour > 12 ? hour - 12 : hour;
        const amPm = hour >= 12 ? 'PM' : 'AM';
        timeSlots.push(`${displayHour}:00 ${amPm}`);
    }
    
    // Create time slots
    timeSlots.forEach(timeSlot => {
        const row = document.createElement('div');
        row.className = 'calendar-row';
        
        // Add time label
        const timeLabel = document.createElement('div');
        timeLabel.className = 'time-label';
        timeLabel.textContent = timeSlot;
        row.appendChild(timeLabel);
        
        // Add day cells
        ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].forEach(day => {
            const cell = document.createElement('div');
            cell.className = 'calendar-cell';
            cell.dataset.day = day;
            cell.dataset.time = timeSlot;
            row.appendChild(cell);
        });
        
        calendarGrid.appendChild(row);
    });
}

// API calls
async function fetchRegisteredCourses() {
    try {
        const token = getToken();
        const response = await fetch('/api/student/schedule', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch registered courses');
        }
        
        const data = await response.json();
        
        if (data.success) {
            registeredCourses = data.courses;
            updateRegisteredCoursesTable();
            updateScheduleDisplay();
        } else {
            console.error('Error loading registered courses:', data.message);
        }
    } catch (error) {
        console.error('Error loading registered courses:', error);
    }
}

// Update Registered Courses Table
function updateRegisteredCoursesTable(courses) {
    const tableBody = document.getElementById('registered-courses-list');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    if (courses.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="6" class="text-center">No courses registered yet</td>';
        tableBody.appendChild(row);
        return;
    }
    
    courses.forEach(course => {
        const row = document.createElement('tr');
        
        const days = Array.isArray(course.days) ? course.days.join(', ') : course.days || 'N/A';
        const courseId = course.courseId || course._id;
        
        row.innerHTML = `
            <td>${course.code || 'N/A'}</td>
            <td>${course.name || 'N/A'}</td>
            <td>${course.instructor || 'N/A'}</td>
            <td>${days}</td>
            <td>${course.startTime || 'N/A'} - ${course.endTime || 'N/A'}</td>
            <td>
                <button class="action-btn drop-btn" onclick="dropCourse('${courseId}')">Drop</button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Update Schedule Display
function updateScheduleDisplay() {
    console.log("Updating schedule with courses:", registeredCourses);
    
    const scheduleBody = document.getElementById('schedule-body');
    if (!scheduleBody) {
        console.error("Schedule body element not found");
        return;
    }
    
    // Clear existing schedule
    scheduleBody.innerHTML = '';
    
    // Create time slots
    const timeSlots = [];
    for (let hour = 8; hour <= 20; hour++) {
        timeSlots.push(`${hour}:00`);
    }
    
    // Create schedule grid
    timeSlots.forEach(time => {
        const row = document.createElement('tr');
        
        // Add time column
        const timeCell = document.createElement('td');
        timeCell.className = 'time-slot';
        timeCell.textContent = time;
        row.appendChild(timeCell);
        
        // Add day columns
        ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].forEach(day => {
            const cell = document.createElement('td');
            cell.className = 'schedule-cell';
            cell.dataset.time = time;
            cell.dataset.day = day;
            row.appendChild(cell);
        });
        
        scheduleBody.appendChild(row);
    });
    
    // Add courses to schedule
    if (registeredCourses && registeredCourses.length > 0) {
        registeredCourses.forEach(course => {
            if (!course.days) {
                console.error("Course has no days:", course);
                return;
            }
            
            const courseDays = Array.isArray(course.days) ? course.days : [course.days];
            
            courseDays.forEach(day => {
                if (!course.startTime || !course.endTime) {
                    console.error("Course missing time information:", course);
                    return;
                }
                
                const startHour = parseInt(course.startTime.split(':')[0]);
                const endHour = parseInt(course.endTime.split(':')[0]);
                
                if (isNaN(startHour) || isNaN(endHour)) {
                    console.error("Invalid time format:", course.startTime, course.endTime);
                    return;
                }
                
                for (let hour = startHour; hour < endHour; hour++) {
                    const timeString = `${hour}:00`;
                    const selector = `.schedule-cell[data-day="${day}"][data-time="${timeString}"]`;
                    const cell = document.querySelector(selector);
                    
                    if (cell) {
                        cell.innerHTML = `
                            <div class="course-block">
                                <div class="course-code">${course.code}</div>
                                <div class="course-name">${course.name}</div>
                            </div>
                        `;
                        cell.classList.add('has-course');
                    } else {
                        console.error(`Cell not found for selector: ${selector}`);
                    }
                }
            });
        });
    }
}

// Direct Register for Course (without preview)
async function directRegisterCourse(courseId) {
    try {
        const token = getToken();
        if (!token) {
            showError('Please log in again');
            return;
        }

        const course = availableCourses.find(c => c._id === courseId);
        if (!course) {
            showError('Course not found');
            return;
        }

        // Register for the course
        const response = await fetch('/api/student/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ courseId })
        });

        const data = await response.json();

        if (data.success) {
            showSuccess('Successfully registered for the course');
            
            // Add course to registered courses array
            if (data.course) {
                registeredCourses.push(data.course);
            } else if (course) {
                // Fallback if server doesn't return the course object
                registeredCourses.push({
                    ...course,
                    courseId: course._id
                });
            }
            
            // Update available seats in the course
            const courseIndex = availableCourses.findIndex(c => c._id === courseId);
            if (courseIndex !== -1) {
                availableCourses[courseIndex].availableSeats--;
            }
            
            // Update UI
            updateAvailableCoursesTable(availableCourses);
            updateRegisteredCoursesTable(registeredCourses);
            updateScheduleDisplay();
            
            // Switch to schedule tab
            openTab('schedule');
        } else {
            showError(data.message || 'Failed to register for the course');
        }
    } catch (error) {
        console.error('Error registering for course:', error);
        showError('An error occurred while registering for the course');
    }
}

// Load Registered Courses
async function loadRegisteredCourses() {
    try {
        const token = getToken();
        if (!token) {
            console.error('No token found');
            return;
        }
        
        const response = await fetch('/api/student/registered-courses', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            registeredCourses = data.courses;
            updateRegisteredCoursesTable(registeredCourses);
            updateScheduleDisplay();
        } else {
            console.error('Failed to load registered courses:', data.message);
        }
    } catch (error) {
        console.error('Error loading registered courses:', error);
    }
}

// Fetch Available Courses
async function fetchAvailableCourses() {
    try {
        const token = getToken();
        const response = await fetch('/api/student/courses', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch courses');
        }
        
        const data = await response.json();
        
        if (data.success) {
            availableCourses = data.courses;
            updateAvailableCoursesTable(availableCourses);
            populateDepartmentFilter(availableCourses);
        } else {
            console.error('Error loading courses:', data.message);
        }
    } catch (error) {
        console.error('Error loading courses:', error);
    }
}

// Populate Department Filter
function populateDepartmentFilter(courses) {
    const departmentFilter = document.getElementById('department-filter');
    if (!departmentFilter) return;
    
    // Clear existing options except the first one
    while (departmentFilter.options.length > 1) {
        departmentFilter.remove(1);
    }
    
    // Get unique departments
    const departments = [...new Set(courses.map(course => course.department))].sort();
    
    // Add department options
    departments.forEach(department => {
        const option = document.createElement('option');
        option.value = department;
        option.textContent = department;
        departmentFilter.appendChild(option);
    });
}

// Filter Courses
function filterCourses() {
    const departmentFilter = document.getElementById('department-filter').value;
    const levelFilter = document.getElementById('level-filter').value;
    const dayFilter = document.getElementById('day-filter').value;
    const timeFilter = document.getElementById('time-filter').value;
    const searchFilter = document.getElementById('search-filter').value.toLowerCase();
    
    // Filter courses based on criteria
    const filteredCourses = availableCourses.filter(course => {
        // Department filter
        if (departmentFilter && course.department !== departmentFilter) {
            return false;
        }
        
        // Level filter
        if (levelFilter && course.level !== levelFilter) {
            return false;
        }
        
        // Day filter
        if (dayFilter && !course.days.includes(dayFilter)) {
            return false;
        }
        
        // Time filter
        if (timeFilter) {
            const startHour = parseTimeString(course.startTime);
            
            if (timeFilter === 'morning' && (startHour < 8 || startHour >= 12)) {
                return false;
            } else if (timeFilter === 'afternoon' && (startHour < 12 || startHour >= 17)) {
                return false;
            } else if (timeFilter === 'evening' && (startHour < 17 || startHour >= 22)) {
                return false;
            }
        }
        
        // Search filter
        if (searchFilter) {
            const matchesCode = course.code.toLowerCase().includes(searchFilter);
            const matchesName = course.name.toLowerCase().includes(searchFilter);
            const matchesInstructor = course.instructor.toLowerCase().includes(searchFilter);
            
            if (!matchesCode && !matchesName && !matchesInstructor) {
                return false;
            }
        }
        
        return true;
    });
    
    updateAvailableCoursesTable(filteredCourses);
}

// Update Available Courses Table
function updateAvailableCoursesTable(courses) {
    const tableBody = document.getElementById('available-courses-list');
    tableBody.innerHTML = '';
    
    if (courses.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="8" class="text-center">No courses available matching your filters</td>';
        tableBody.appendChild(row);
        return;
    }
    
    courses.forEach(course => {
        const row = document.createElement('tr');
        
        // Format days array for display
        const daysDisplay = Array.isArray(course.days) ? course.days.join(', ') : course.days;
        
        row.innerHTML = `
            <td>${course.code}</td>
            <td>${course.name}</td>
            <td>${course.department}</td>
            <td>${course.instructor}</td>
            <td>${daysDisplay}</td>
            <td>${course.startTime} - ${course.endTime}</td>
            <td><span class="seats-count">${course.availableSeats}</span> / ${course.capacity}</td>
            <td>
                <button class="action-btn register-btn" onclick="directRegisterCourse('${course._id}')">Register</button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Socket.io for real-time updates
function setupSocketListeners() {
    // Listen for seat updates
    socket.on('seatUpdate', (data) => {
        // Update course in available courses list
        const courseIndex = availableCourses.findIndex(c => c._id === data.courseId);
        if (courseIndex !== -1) {
            availableCourses[courseIndex].availableSeats = data.availableSeats;
            updateAvailableCoursesTable(availableCourses);
        }
        
        // Update course in preview modal if it's the same course
        if (currentlyViewingCourse && currentlyViewingCourse._id === data.courseId) {
            document.getElementById('preview-seats').textContent = `${data.availableSeats} of ${data.capacity}`;
        }
    });
    
    // Listen for course added event
    socket.on('courseAdded', (course) => {
        availableCourses.push(course);
        updateAvailableCoursesTable(availableCourses);
        populateDepartmentFilter(availableCourses);
    });
    
    // Listen for course updated event
    socket.on('courseUpdated', (updatedCourse) => {
        const courseIndex = availableCourses.findIndex(c => c._id === updatedCourse._id);
        if (courseIndex !== -1) {
            availableCourses[courseIndex] = updatedCourse;
            updateAvailableCoursesTable(availableCourses);
        }
    });
    
    // Listen for course deleted event
    socket.on('courseDeleted', (courseId) => {
        availableCourses = availableCourses.filter(c => c._id !== courseId);
        updateAvailableCoursesTable(availableCourses);
    });
}

// Drop a course
async function dropCourse(courseId) {
    try {
        if (!confirm('Are you sure you want to drop this course?')) {
            return;
        }

        const response = await fetch(`/api/student/courses/${courseId}/drop`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            }
        });

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message || 'Failed to drop course');
        }

        // Refresh the registered courses and available courses
        loadRegisteredCourses();
        fetchAvailableCourses();
        
        showSuccess('Course dropped successfully');
        
        // Emit socket event to notify other users
        socket.emit('courseUpdated', { courseId });
    } catch (error) {
        console.error('Error dropping course:', error);
        showError(error.message);
    }
}

// Utility functions
function showError(message) {
    // Remove any existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Create error alert
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-error';
    alertDiv.textContent = message;
    
    // Add close button
    const closeBtn = document.createElement('span');
    closeBtn.innerHTML = '&times;';
    closeBtn.className = 'close-btn';
    closeBtn.style.float = 'right';
    closeBtn.style.cursor = 'pointer';
    closeBtn.style.fontWeight = 'bold';
    closeBtn.onclick = function() {
        alertDiv.remove();
    };
    
    alertDiv.prepend(closeBtn);
    
    // Add to document
    document.body.appendChild(alertDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

function showSuccess(message) {
    // Remove any existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Create success alert
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success';
    alertDiv.textContent = message;
    
    // Add close button
    const closeBtn = document.createElement('span');
    closeBtn.innerHTML = '&times;';
    closeBtn.className = 'close-btn';
    closeBtn.style.float = 'right';
    closeBtn.style.cursor = 'pointer';
    closeBtn.style.fontWeight = 'bold';
    closeBtn.onclick = function() {
        alertDiv.remove();
    };
    
    alertDiv.prepend(closeBtn);
    
    // Add to document
    document.body.appendChild(alertDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Logout function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('studentId');
    localStorage.removeItem('studentName');
    localStorage.removeItem('rollNumber');
    window.location.href = '/auth/student/login';
}
