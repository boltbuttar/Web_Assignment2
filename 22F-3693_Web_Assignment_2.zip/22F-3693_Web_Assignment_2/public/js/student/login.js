document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('student-login-form');
    const errorMessage = document.getElementById('error-message');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Clear previous error messages
        errorMessage.style.display = 'none';
        errorMessage.textContent = '';
        
        // Get roll number
        const rollNumber = document.getElementById('rollNumber').value.trim();
        
        if (!rollNumber) {
            errorMessage.textContent = 'Please enter your roll number';
            errorMessage.style.display = 'block';
            return;
        }
        
        try {
            // Show loading state
            const submitButton = loginForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.textContent;
            submitButton.textContent = 'Signing in...';
            submitButton.disabled = true;
            
            // Send login request
            const response = await fetch('/auth/student/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ rollNumber })
            });
            
            const data = await response.json();
            
            // Reset button state
            submitButton.textContent = originalButtonText;
            submitButton.disabled = false;
            
            if (data.success) {
                // Store token in localStorage
                localStorage.setItem('token', data.token);
                
                // Redirect to dashboard
                window.location.href = data.redirect;
            } else {
                // Show error message
                errorMessage.textContent = data.message;
                errorMessage.style.display = 'block';
            }
        } catch (error) {
            console.error('Login error:', error);
            // Show error message
            errorMessage.textContent = 'An error occurred during login';
            errorMessage.style.display = 'block';
            
            // Reset button state
            const submitButton = loginForm.querySelector('button[type="submit"]');
            submitButton.textContent = 'Sign In';
            submitButton.disabled = false;
        }
    });
});
