function redirectToLogin(userType) {
    if (userType === "student") {
        window.location.href = "/auth/student/login";  // Redirect to correct route
    } else if (userType === "admin") {
        window.location.href = "/auth/admin/login";    
    }
}
