document.getElementById('studentLoginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const rollNumber = document.getElementById('rollNumber').value;

    const response = await fetch('/auth/student-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rollNumber })
    });

    const data = await response.json();

    if (data.success) {
        window.location.href = '/student/dashboard';
    } else {
        document.getElementById('errorMessage').innerText = data.message;
    }
});
