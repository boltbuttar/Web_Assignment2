document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('adminLoginForm');
    const errorMessage = document.getElementById('errorMessage');

    // Check if already logged in
    const token = localStorage.getItem('adminToken');
    if (token) {
        // Add token to headers and redirect
        fetch('/admin/dashboard', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        }).then(response => {
            if (response.ok) {
                window.location.href = '/admin/dashboard';
            } else {
                // Token invalid, remove it
                localStorage.removeItem('adminToken');
                localStorage.removeItem('adminId');
                localStorage.removeItem('adminUsername');
            }
        }).catch(error => {
            console.error('Error checking auth:', error);
            // Token invalid, remove it
            localStorage.removeItem('adminToken');
            localStorage.removeItem('adminId');
            localStorage.removeItem('adminUsername');
        });
        return;
    }

    document.getElementById('admin-login-form').addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('/auth/admin/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (data.success) {
                // Store token
                localStorage.setItem('token', data.token);
                
                // Redirect to dashboard
                window.location.href = data.redirect;
            } else {
                // Show error message
                const errorDiv = document.getElementById('error-message');
                errorDiv.textContent = data.message;
                errorDiv.style.display = 'block';
            }
        } catch (error) {
            console.error('Login error:', error);
            const errorDiv = document.getElementById('error-message');
            errorDiv.textContent = 'An error occurred during login';
            errorDiv.style.display = 'block';
        }
    });
});

// Helper function to show error message
function showError(message) {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
}
