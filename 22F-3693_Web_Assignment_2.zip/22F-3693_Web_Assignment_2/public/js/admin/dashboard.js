// Add auth check at the start
document.addEventListener('DOMContentLoaded', () => {
    // Check if user is authenticated
    const token = localStorage.getItem('adminToken');
    if (!token) {
        window.location.href = '/auth/admin/login';
        return;
    }

    // Add token to all fetch requests
    const originalFetch = window.fetch;
    window.fetch = function() {
        let [resource, config] = arguments;
        if (!config) {
            config = {};
        }
        if (!config.headers) {
            config.headers = {};
        }
        config.headers['Authorization'] = `Bearer ${token}`;
        return originalFetch(resource, config);
    };

    // Initialize the dashboard
    setupNavigation();
    setupFormListeners();
    setupFilters();
    fetchCourses();
    fetchStudents();
});

// Student API functions
async function fetchStudents() {
    try {
        const response = await fetch('/admin/students');
        
        if (!response.ok) {
            throw new Error('Failed to fetch students');
        }
        
        const students = await response.json();
        
        // Store students globally
        allStudents = students;
        
        // Display students
        const studentList = document.getElementById('students-list');
        if (!studentList) return;
        
        studentList.innerHTML = '';
        
        if (allStudents.length === 0) {
            studentList.innerHTML = '<tr><td colspan="5" class="text-center">No students found</td></tr>';
            return;
        }
        
        allStudents.forEach(student => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${student.rollNumber}</td>
                <td>${student.name}</td>
                <td>${student.department || 'N/A'}</td>
                <td>${student.courses.length > 0 
                    ? student.courses.map(course => course.code || course).join(', ')
                    : 'None'}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn icon view-btn" data-id="${student._id}">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn icon remove-student-btn" data-id="${student._id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;
            
            // Add event listener to view button
            const viewBtn = row.querySelector('.view-btn');
            viewBtn.addEventListener('click', () => viewStudentDetails(student._id));
            
            // Add event listener to remove button
            const removeBtn = row.querySelector('.remove-student-btn');
            removeBtn.addEventListener('click', () => deleteStudent(student._id));
            
            studentList.appendChild(row);
        });
    } catch (error) {
        console.error('Error fetching students:', error);
        showNotification(error.message, 'error');
    }
}

async function addStudent(studentData) {
    try {
        const response = await fetch('/admin/students', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(studentData)
        });
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to add student');
        }
        
        // Close the modal
        document.getElementById('add-student-form').style.display = 'none';
        
        // Reset the form
        document.getElementById('student-form').reset();
        
        // Refresh students list
        await fetchStudents();
        
        showNotification('Student added successfully', 'success');
    } catch (error) {
        console.error('Error adding student:', error);
        showNotification(error.message, 'error');
    }
}

async function deleteStudent(studentId) {
    try {
        // Confirm deletion
        if (!confirm('Are you sure you want to remove this student?')) {
            return;
        }
        
        const response = await fetch(`/admin/students/${studentId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to remove student');
        }
        
        // Refresh students list
        await fetchStudents();
        
        showNotification('Student removed successfully', 'success');
    } catch (error) {
        console.error('Error removing student:', error);
        showNotification(error.message, 'error');
    }
}

// Course API functions
async function fetchCourses() {
    try {
        const response = await fetch('/api/admin/courses');
        
        if (!response.ok) {
            throw new Error('Failed to fetch courses');
        }
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to fetch courses');
        }
        
        allCourses = data.courses || [];
        
        // Populate department filter
        populateDepartmentFilter(allCourses);
        
        // Display courses
        displayCourses(allCourses);
    } catch (error) {
        console.error('Error fetching courses:', error);
        showNotification(error.message, 'error');
    }
}

// Display courses in the table
function displayCourses(courses) {
    const coursesList = document.getElementById('courses-list');
    if (!coursesList) return;
    
    coursesList.innerHTML = '';
    
    if (courses.length === 0) {
        coursesList.innerHTML = '<tr><td colspan="8" class="text-center">No courses found</td></tr>';
        return;
    }
    
    courses.forEach(course => {
        const row = document.createElement('tr');
        row.dataset.id = course._id;
        
        row.innerHTML = `
            <td>${course.code}</td>
            <td>${course.name}</td>
            <td>${course.department || 'N/A'}</td>
            <td>${course.level || 'N/A'}</td>
            <td>${course.instructor || 'N/A'}</td>
            <td>${course.schedule && course.schedule.days 
                ? `${course.schedule.days.join(', ')} at ${course.schedule.time || 'TBD'}` 
                : 'Not scheduled'}</td>
            <td>${course.capacity || 0}</td>
            <td>${course.enrolled || 0}</td>
            <td class="${(course.enrolled || 0) >= (course.capacity || 1) ? 'text-danger' : 'text-success'}">
                ${(course.enrolled || 0) >= (course.capacity || 1) ? 'Full' : 'Available'}
            </td>
            <td>
                <button class="btn btn-primary edit-course" data-id="${course._id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger delete-course" data-id="${course._id}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        coursesList.appendChild(row);
    });
    
    // Add event listeners to edit and delete buttons
    document.querySelectorAll('.edit-course').forEach(button => {
        button.addEventListener('click', () => editCourse(button.dataset.id));
    });
    
    document.querySelectorAll('.delete-course').forEach(button => {
        button.addEventListener('click', () => deleteCourse(button.dataset.id));
    });
}

async function addCourse(courseData) {
    try {
        const response = await fetch('/api/admin/courses', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(courseData)
        });
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to add course');
        }
        
        // Close the modal
        document.getElementById('add-course-form').style.display = 'none';
        
        // Reset the form
        document.getElementById('course-form').reset();
        
        // Refresh courses list
        await fetchCourses();
        
        showNotification('Course added successfully', 'success');
    } catch (error) {
        console.error('Error adding course:', error);
        showNotification(error.message, 'error');
    }
}

// Navigation setup
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            const tabId = link.getAttribute('data-tab');
            openTab(tabId);
        });
    });
}

function openTab(tabId) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
    });
    
    // Remove active class from all nav links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabId).style.display = 'block';
    
    // Add active class to selected nav link
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
}

// Form setup
function setupFormListeners() {
    // Course form
    const courseForm = document.getElementById('course-form');
    if (courseForm) {
        courseForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const courseData = {
                code: document.getElementById('code').value,
                name: document.getElementById('name').value,
                instructor: document.getElementById('instructor').value,
                department: document.getElementById('department').value,
                schedule: {
                    days: Array.from(document.querySelectorAll('input[name="days"]:checked')).map(cb => cb.value),
                    time: document.getElementById('time').value
                },
                capacity: parseInt(document.getElementById('capacity').value)
            };
            
            await addCourse(courseData);
        });
    }
    
    // Student form
    const studentForm = document.getElementById('student-form');
    if (studentForm) {
        studentForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const studentData = {
                rollNumber: document.getElementById('rollNumber').value,
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                department: document.getElementById('department').value,
                semester: parseInt(document.getElementById('semester').value)
            };
            
            await addStudent(studentData);
        });
    }
}

// Filter setup
function setupFilters() {
    // Course filters
    document.getElementById('course-filter')?.addEventListener('input', filterCourses);
    document.getElementById('department-filter')?.addEventListener('change', filterCourses);
    
    // Student filters
    document.getElementById('student-filter')?.addEventListener('input', filterStudents);
    document.getElementById('student-department-filter')?.addEventListener('change', filterStudents);
}

// Global variables
let allCourses = [];
let allStudents = [];

// Function to populate department filter
function populateDepartmentFilter(courses) {
    const departmentFilter = document.getElementById('department-filter');
    if (!departmentFilter) return;
    
    const departments = [...new Set(courses.map(course => course.department))];
    departmentFilter.innerHTML = '';
    
    departments.forEach(department => {
        const option = document.createElement('option');
        option.value = department;
        option.text = department;
        departmentFilter.appendChild(option);
    });
}

// Function to filter courses
function filterCourses() {
    const courseFilter = document.getElementById('course-filter').value.toLowerCase();
    const departmentFilter = document.getElementById('department-filter').value;
    
    const coursesList = document.getElementById('courses-list');
    if (!coursesList) return;
    
    const rows = coursesList.children;
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const courseCode = row.children[0].textContent.toLowerCase();
        const courseDepartment = row.children[2].textContent;
        
        if ((courseCode.includes(courseFilter) || courseFilter === '') && (courseDepartment === departmentFilter || departmentFilter === '')) {
            row.style.display = 'table-row';
        } else {
            row.style.display = 'none';
        }
    }
}

// Function to filter students
function filterStudents() {
    const studentFilter = document.getElementById('student-filter').value.toLowerCase();
    const departmentFilter = document.getElementById('student-department-filter').value;
    
    const studentList = document.getElementById('students-list');
    if (!studentList) return;
    
    const rows = studentList.children;
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const studentName = row.children[1].textContent.toLowerCase();
        const studentDepartment = row.children[2].textContent;
        
        if ((studentName.includes(studentFilter) || studentFilter === '') && (studentDepartment === departmentFilter || departmentFilter === '')) {
            row.style.display = 'table-row';
        } else {
            row.style.display = 'none';
        }
    }
}

// Function to show notification
function showNotification(message, type) {
    const notification = document.getElementById('notification');
    if (!notification) return;
    
    notification.textContent = message;
    notification.classList.remove('success', 'error');
    notification.classList.add(type);
    notification.style.display = 'block';
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Function to view student details
function viewStudentDetails(studentId) {
    // TO DO: implement view student details functionality
}

// Function to edit course
function editCourse(courseId) {
    // TO DO: implement edit course functionality
}

// Function to delete course
function deleteCourse(courseId) {
    // TO DO: implement delete course functionality
}
