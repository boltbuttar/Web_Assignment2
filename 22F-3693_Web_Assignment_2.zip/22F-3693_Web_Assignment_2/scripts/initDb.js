const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const Student = require('../models/Student');
const Course = require('../models/Course');
const Admin = require('../models/Admin');
const connectDB = require('../config/db');

// Load environment variables
dotenv.config();

// Connect to MongoDB using the existing configuration
connectDB()
    .then(() => console.log("Ready to initialize database"))
    .catch(err => {
        console.error("Failed to connect to database:", err);
        process.exit(1);
    });

// Sample course data
const coursesData = [
    {
        name: "Programming Fundamentals",
        code: "CS101",
        department: "Computer Science",
        level: "Undergraduate",
        instructor: "Dr. Adnan",
        days: ["Monday", "Wednesday"],
        startTime: "10:00 AM",
        endTime: "11:30 AM",
        description: "Introduction to programming concepts, algorithms, and problem-solving techniques using a high-level programming language.",
        credits: 3,
        capacity: 50,
        availableSeats: 50,
        enrolled: 0,
        prerequisites: []
    },
    {
        name: "Object Oriented Programming",
        code: "CS201",
        department: "Computer Science",
        level: "Undergraduate",
        instructor: "Dr.Ijaz",
        days: ["Tuesday", "Thursday"],
        startTime: "1:00 PM",
        endTime: "2:30 PM",
        description: "Principles of object-oriented programming including classes, objects, inheritance, polymorphism, and encapsulation.",
        credits: 3,
        capacity: 40,
        availableSeats: 40,
        enrolled: 0,
        prerequisites: [] 
    },
    {
        name: "Data Structures",
        code: "CS301",
        department: "Computer Science",
        level: "Undergraduate",
        instructor: "Dr. Aamir",
        days: ["Monday", "Wednesday"],
        startTime: "2:00 PM",
        endTime: "3:30 PM",
        description: "Implementation and analysis of fundamental data structures including arrays, linked lists, stacks, queues, trees, and graphs.",
        credits: 3,
        capacity: 35,
        availableSeats: 35,
        enrolled: 0,
        prerequisites: [] 
    },
    {
        name: "Database Systems",
        code: "CS401",
        department: "Computer Science",
        level: "Undergraduate",
        instructor: "Dr. Edgar Codd",
        days: ["Tuesday", "Thursday"],
        startTime: "10:00 AM",
        endTime: "11:30 AM",
        description: "Fundamentals of database design, implementation, and management including data models, query languages, and transactions.",
        credits: 3,
        capacity: 30,
        availableSeats: 30,
        enrolled: 0,
        prerequisites: [] 
    },
    {
        name: "Calculus I",
        code: "MATH101",
        department: "Mathematics",
        level: "Undergraduate",
        instructor: "Dr.Nawaz",
        days: ["Monday", "Wednesday", "Friday"],
        startTime: "9:00 AM",
        endTime: "10:00 AM",
        description: "Introduction to differential and integral calculus of functions of one variable.",
        credits: 4,
        capacity: 60,
        availableSeats: 60,
        enrolled: 0,
        prerequisites: []
    },
    {
        name: "Linear Algebra",
        code: "MATH201",
        department: "Mathematics",
        level: "Undergraduate",
        instructor: "Mr. Farooq",
        days: ["Tuesday", "Thursday"],
        startTime: "11:00 AM",
        endTime: "12:30 PM",
        description: "Study of vector spaces, linear transformations, matrices, and systems of linear equations.",
        credits: 3,
        capacity: 45,
        availableSeats: 45,
        enrolled: 0,
        prerequisites: []
    }
];

// Sample student data
const studentsData = [
    {
        rollNumber: "22F-3693",
        name: "Furqan Asghar",
        email: "furqan@github.io",
        department: "Computer Science",
        semester: 3,
        courses: [],
        completedCourses: [
            {
                code: "CS101",
                name: "Programming Fundamentals",
                grade: "A"
            }
        ]
    }
];

// Sample admin data
const adminsData = [
    {
        username: "admin",
        password: "admin123"
    }
];

// Initialize database
async function initializeDatabase() {
    try {
        // Clear existing data
        await Student.deleteMany({});
        await Course.deleteMany({});
        await Admin.deleteMany({});

        console.log("Existing data cleared");

        // Insert courses
        const courses = await Course.insertMany(coursesData);
        console.log(`${courses.length} courses inserted`);

        // Update prerequisites
        // CS201 (OOP) requires CS101 (Programming Fundamentals)
        await Course.findOneAndUpdate(
            { code: "CS201" },
            { $set: { prerequisites: [courses.find(c => c.code === "CS101")._id] } }
        );

        // CS301 (Data Structures) requires CS201 (OOP)
        await Course.findOneAndUpdate(
            { code: "CS301" },
            { $set: { prerequisites: [courses.find(c => c.code === "CS201")._id] } }
        );

        // CS401 (Database Systems) requires CS301 (Data Structures)
        await Course.findOneAndUpdate(
            { code: "CS401" },
            { $set: { prerequisites: [courses.find(c => c.code === "CS301")._id] } }
        );

        console.log("Course prerequisites updated");

        // Insert students with completed courses
        const students = await Promise.all(
            studentsData.map(async student => {
                // Find the CS101 course to add as completed
                const cs101 = courses.find(c => c.code === "CS101");
                
                if (cs101) {
                    // Update the completedCourses with the actual course ID
                    student.completedCourses = [
                        {
                            courseId: cs101._id,
                            code: cs101.code,
                            name: cs101.name,
                            grade: "A"
                        }
                    ];
                }
                
                const newStudent = new Student(student);
                await newStudent.save();
                return newStudent;
            })
        );
        console.log(`${students.length} students inserted`);

        // Insert admins (with hashed passwords)
        const admins = await Promise.all(
            adminsData.map(async admin => {
                const salt = await bcrypt.genSalt(10);
                const hashedPassword = await bcrypt.hash(admin.password, salt);
                
                const newAdmin = new Admin({
                    username: admin.username,
                    password: hashedPassword
                });
                
                await newAdmin.save();
                return newAdmin;
            })
        );
        console.log(`${admins.length} admins inserted`);

        console.log("Database initialization completed successfully");
        process.exit(0);
    } catch (error) {
        console.error("Error initializing database:", error);
        process.exit(1);
    }
}

// Run the initialization
initializeDatabase();
