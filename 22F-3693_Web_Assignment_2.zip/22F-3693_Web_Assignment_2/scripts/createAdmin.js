const mongoose = require('mongoose');
const Admin = require('../models/Admin');

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI || "mongodb://localhost:27017/university", { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
.then(() => console.log("MongoDB Connected"))
.catch((err) => console.error("MongoDB Connection Error:", err));

// Create default admin user
async function createDefaultAdmin() {
    try {
        // Check if admin exists
        const adminExists = await Admin.findOne({ username: 'admin' });
        
        if (!adminExists) {
            const admin = new Admin({
                username: 'admin',
                password: 'admin123'
            });
            
            await admin.save();
            console.log('Default admin user created successfully');
        } else {
            console.log('Default admin user already exists');
        }
    } catch (error) {
        console.error('Error creating default admin:', error);
    } finally {
        mongoose.connection.close();
    }
}

createDefaultAdmin();
