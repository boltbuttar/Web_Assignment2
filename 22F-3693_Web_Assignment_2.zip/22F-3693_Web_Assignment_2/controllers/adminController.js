const jwt = require("jsonwebtoken");
const Course = require("../models/Course");
const Student = require("../models/Student");

// ✅ Render Admin Dashboard
const getAdminDashboard = async (req, res) => {
    try {
        const adminId = req.user.id;
        
        // Get course statistics
        const totalCourses = await Course.countDocuments();
        const courses = await Course.find().lean();
        const coursesByDepartment = {};
        const courseEnrollmentRates = {};
        
        // Process courses for stats
        for (const course of courses) {
            // Group by department
            const dept = course.department || 'Uncategorized';
            if (!coursesByDepartment[dept]) {
                coursesByDepartment[dept] = 0;
            }
            coursesByDepartment[dept]++;
            
            // Calculate enrollment rates
            const enrolledCount = course.enrolled || 0;
            const capacity = course.capacity || 1; // Avoid division by zero
            courseEnrollmentRates[course.code] = enrolledCount / capacity;
        }
        
        // Get student statistics
        const totalStudents = await Student.countDocuments();
        const totalEnrollments = await Student.countDocuments({ 'courses.0': { $exists: true } });
        
        // Render dashboard with data
        res.render('admin/dashboard', {
            title: "Admin Dashboard",
            admin: {
                id: adminId,
                name: req.user.username || 'Admin'
            },
            courses: courses || [],
            students: await Student.find().lean() || [],
            stats: {
                totalCourses,
                totalStudents,
                totalEnrollments,
                coursesByDepartment,
                courseEnrollmentRates
            }
        });
    } catch (error) {
        console.error("Admin Dashboard Error:", error);
        res.status(500).render('errors/500', { 
            message: "Server error",
            redirectUrl: "/auth/admin"
        });
    }
};

// Get courses by department for stats
const getCoursesByDepartment = async () => {
    try {
        const departments = await Course.aggregate([
            { $group: { _id: "$department", count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]);
        
        return departments.map(dept => ({
            name: dept._id || 'Uncategorized',
            count: dept.count
        }));
    } catch (error) {
        console.error("Error getting courses by department:", error);
        return [];
    }
};

// ✅ Get all courses
const getCourses = async (req, res) => {
    try {
        const courses = await Course.find().sort({ department: 1, code: 1 });
        res.json(courses); 
    } catch (error) {
        console.error("Error fetching courses:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// ✅ Get all students
const getStudents = async (req, res) => {
    try {
        const students = await Student.find().sort({ name: 1 });
        res.json(students); 
    } catch (error) {
        console.error("Error fetching students:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// ✅ Add a new course
const addCourse = async (req, res) => {
    try {
        const { 
            code, 
            name, 
            instructor,
            department,
            level,
            credits,
            capacity,
            description,
            schedule
        } = req.body;
        
        // Validate required fields
        if (!code || !name || !instructor || !department || !schedule || !schedule.days || !schedule.time) {
            return res.status(400).json({ 
                success: false, 
                message: "Please provide all required fields" 
            });
        }
        
        // Check if course code already exists
        const existingCourse = await Course.findOne({ code });
        if (existingCourse) {
            return res.status(400).json({ 
                success: false, 
                message: "A course with this code already exists" 
            });
        }
        
        // Create new course
        const newCourse = new Course({
            code,
            name,
            instructor,
            department,
            level,
            credits: credits || 3,
            capacity: capacity || 30,
            description: description || `Course: ${name}`,
            schedule,
            enrolled: 0
        });
        
        await newCourse.save();
        
        // Emit socket event for real-time updates
        req.app.get('io').emit('courseAdded', newCourse);
        
        res.status(201).json({ 
            success: true, 
            message: "Course added successfully", 
            course: newCourse 
        });
    } catch (error) {
        console.error("Error adding course:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// ✅ Edit a course
const editCourse = async (req, res) => {
    try {
        const courseId = req.params.id;
        const { 
            code, 
            name, 
            instructor,
            department,
            level,
            credits,
            capacity,
            description,
            schedule
        } = req.body;
        
        // Validate required fields
        if (!code || !name || !instructor || !department || !schedule || !schedule.days || !schedule.time) {
            return res.status(400).json({ 
                success: false, 
                message: "Please provide all required fields" 
            });
        }
        
        // Find course by ID
        const course = await Course.findById(courseId);
        if (!course) {
            return res.status(404).json({ 
                success: false, 
                message: "Course not found" 
            });
        }
        
        // Check if another course has the same code
        if (code !== course.code) {
            const existingCourse = await Course.findOne({ code });
            if (existingCourse) {
                return res.status(400).json({ 
                    success: false, 
                    message: "Another course with this code already exists" 
                });
            }
        }
        
        // Update course
        course.code = code;
        course.name = name;
        course.instructor = instructor;
        course.department = department;
        course.level = level;
        course.credits = credits;
        course.capacity = capacity;
        course.description = description;
        course.schedule = schedule;
        
        await course.save();
        
        // Emit socket event for real-time updates
        req.app.get('io').emit('courseUpdated', course);
        
        res.json({ 
            success: true, 
            message: "Course updated successfully", 
            course 
        });
    } catch (error) {
        console.error("Error updating course:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// ✅ Delete a course
const deleteCourse = async (req, res) => {
    try {
        const courseId = req.params.id;
        
        // Find course by ID
        const course = await Course.findById(courseId);
        if (!course) {
            return res.status(404).json({ 
                success: false, 
                message: "Course not found" 
            });
        }
        
        // Check if any students are registered for this course
        const studentsWithCourse = await Student.find({ 'courses.courseId': courseId });
        
        if (studentsWithCourse.length > 0) {
            // Update each student to remove the course
            for (const student of studentsWithCourse) {
                student.courses = student.courses.filter(c => c.courseId.toString() !== courseId);
                await student.save();
            }
        }
        
        // Delete the course
        await Course.findByIdAndDelete(courseId);
        
        // Emit socket event for real-time updates
        req.app.get('io').emit('courseDeleted', { courseId });
        
        res.json({ 
            success: true, 
            message: "Course deleted successfully" 
        });
    } catch (error) {
        console.error("Error deleting course:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// ✅ Generate reports
const generateReports = async (req, res) => {
    try {
        const reportType = req.params.type;
        
        let report = {};
        
        switch (reportType) {
            case 'enrollment':
                report = await generateEnrollmentReport();
                break;
            case 'department':
                report = await generateDepartmentReport();
                break;
            case 'capacity':
                report = await generateCapacityReport();
                break;
            default:
                return res.status(400).json({ 
                    success: false, 
                    message: "Invalid report type" 
                });
        }
        
        res.json({ 
            success: true, 
            report 
        });
    } catch (error) {
        console.error("Error generating report:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// Generate enrollment report
const generateEnrollmentReport = async () => {
    try {
        const courses = await Course.find().sort({ name: 1 });
        
        return {
            title: "Course Enrollment Report",
            data: courses.map(course => ({
                code: course.code,
                name: course.name,
                capacity: course.capacity,
                enrolled: course.capacity - course.availableSeats,
                availableSeats: course.availableSeats,
                fillRate: ((course.capacity - course.availableSeats) / course.capacity * 100).toFixed(1) + '%'
            }))
        };
    } catch (error) {
        console.error("Error generating enrollment report:", error);
        return { title: "Error", data: [] };
    }
};

// Generate department report
const generateDepartmentReport = async () => {
    try {
        const departments = await Course.aggregate([
            { $group: { 
                _id: "$department", 
                courseCount: { $sum: 1 },
                totalCapacity: { $sum: "$capacity" },
                totalEnrolled: { $sum: { $subtract: ["$capacity", "$availableSeats"] } }
            }},
            { $sort: { _id: 1 } }
        ]);
        
        return {
            title: "Department Statistics Report",
            data: departments.map(dept => ({
                department: dept._id,
                courseCount: dept.courseCount,
                totalCapacity: dept.totalCapacity,
                totalEnrolled: dept.totalEnrolled,
                fillRate: ((dept.totalEnrolled / dept.totalCapacity) * 100).toFixed(1) + '%'
            }))
        };
    } catch (error) {
        console.error("Error generating department report:", error);
        return { title: "Error", data: [] };
    }
};

// Generate capacity report
const generateCapacityReport = async () => {
    try {
        // Find courses with high fill rates (>90%)
        const highDemandCourses = await Course.find({
            $expr: {
                $gt: [
                    { $multiply: [
                        { $divide: [
                            { $subtract: ["$capacity", "$availableSeats"] },
                            "$capacity"
                        ]},
                        100
                    ]},
                    90
                ]
            }
        }).sort({ availableSeats: 1 });
        
        return {
            title: "High Demand Courses Report",
            data: highDemandCourses.map(course => ({
                code: course.code,
                name: course.name,
                capacity: course.capacity,
                availableSeats: course.availableSeats,
                fillRate: ((course.capacity - course.availableSeats) / course.capacity * 100).toFixed(1) + '%'
            }))
        };
    } catch (error) {
        console.error("Error generating capacity report:", error);
        return { title: "Error", data: [] };
    }
};

// Add a new student
const addStudent = async (req, res) => {
    try {
        const { 
            rollNumber, 
            name, 
            email, 
            password,
            department,
            semester
        } = req.body;
        
        // Validate required fields
        if (!rollNumber || !name || !email || !password || !department || !semester) {
            return res.status(400).json({ 
                success: false, 
                message: "Please provide all required fields" 
            });
        }
        
        // Check if student with same roll number exists
        const existingStudent = await Student.findOne({ rollNumber });
        if (existingStudent) {
            return res.status(400).json({ 
                success: false, 
                message: "A student with this roll number already exists" 
            });
        }
        
        // Create new student
        const newStudent = new Student({
            rollNumber,
            name,
            email,
            password, // Note: In production, this should be hashed
            department,
            semester: parseInt(semester),
            courses: []
        });
        
        await newStudent.save();
        
        // Emit socket event for real-time updates
        req.app.get('io').emit('studentAdded', newStudent);
        
        res.status(201).json({ 
            success: true, 
            message: "Student added successfully", 
            student: newStudent 
        });
    } catch (error) {
        console.error("Error adding student:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// Edit a student
const editStudent = async (req, res) => {
    try {
        const studentId = req.params.id;
        const { 
            rollNumber, 
            name, 
            email,
            department,
            semester
        } = req.body;
        
        // Validate required fields
        if (!rollNumber || !name || !email || !department || !semester) {
            return res.status(400).json({ 
                success: false, 
                message: "Please provide all required fields" 
            });
        }
        
        // Find student by ID
        const student = await Student.findById(studentId);
        if (!student) {
            return res.status(404).json({ 
                success: false, 
                message: "Student not found" 
            });
        }
        
        // Check if another student has the same roll number
        if (rollNumber !== student.rollNumber) {
            const existingStudent = await Student.findOne({ rollNumber });
            if (existingStudent) {
                return res.status(400).json({ 
                    success: false, 
                    message: "Another student with this roll number already exists" 
                });
            }
        }
        
        // Update student
        student.rollNumber = rollNumber;
        student.name = name;
        student.email = email;
        student.department = department;
        student.semester = semester;
        
        await student.save();
        
        // Emit socket event for real-time updates
        req.app.get('io').emit('studentUpdated', student);
        
        res.json({ 
            success: true, 
            message: "Student updated successfully", 
            student 
        });
    } catch (error) {
        console.error("Error updating student:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

// Delete a student
const deleteStudent = async (req, res) => {
    try {
        const studentId = req.params.id;
        
        // Find and delete student
        const student = await Student.findByIdAndDelete(studentId);
        
        if (!student) {
            return res.status(404).json({ 
                success: false, 
                message: "Student not found" 
            });
        }
        
        // Emit socket event for real-time updates
        req.app.get('io').emit('studentDeleted', studentId);
        
        res.json({ 
            success: true, 
            message: "Student deleted successfully" 
        });
    } catch (error) {
        console.error("Error deleting student:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};

module.exports = {
    getAdminDashboard,
    getCourses,
    getStudents,
    addCourse,
    editCourse,
    deleteCourse,
    addStudent,
    editStudent,
    deleteStudent,
    generateReports
};
