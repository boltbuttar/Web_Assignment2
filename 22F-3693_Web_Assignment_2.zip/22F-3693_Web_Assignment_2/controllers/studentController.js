const jwt = require("jsonwebtoken");
const Student = require("../models/Student");
const Course = require("../models/Course");

// Helper function to check for schedule conflicts
const checkScheduleConflict = (newCourse, existingCourses) => {
    // Convert day names to lowercase for case-insensitive comparison
    const newCourseDays = newCourse.days.map(day => day.toLowerCase());
    
    for (const existingCourse of existingCourses) {
        // Skip if the course doesn't have days property (for compatibility with different data structures)
        if (!existingCourse.days) continue;
        
        const existingCourseDays = Array.isArray(existingCourse.days) 
            ? existingCourse.days.map(day => day.toLowerCase())
            : [existingCourse.days.toLowerCase()];
        
        // Check for day overlap
        const hasOverlappingDays = newCourseDays.some(day => 
            existingCourseDays.includes(day)
        );
        
        if (hasOverlappingDays) {
            // Convert times to minutes for easier comparison
            const newStartMinutes = parseTimeToMinutes(newCourse.startTime);
            const newEndMinutes = parseTimeToMinutes(newCourse.endTime);
            const existingStartMinutes = parseTimeToMinutes(existingCourse.startTime);
            const existingEndMinutes = parseTimeToMinutes(existingCourse.endTime);
            
            // Check for time overlap
            if (
                (newStartMinutes >= existingStartMinutes && newStartMinutes < existingEndMinutes) ||
                (newEndMinutes > existingStartMinutes && newEndMinutes <= existingEndMinutes) ||
                (newStartMinutes <= existingStartMinutes && newEndMinutes >= existingEndMinutes)
            ) {
                return true;
            }
        }
    }
    
    return false;
};

// Helper function to convert time string to minutes
const parseTimeToMinutes = (timeString) => {
    // Handle different time formats
    let hours, minutes;
    
    if (timeString.includes(':')) {
        [hours, minutes] = timeString.split(':').map(Number);
    } else if (timeString.includes('AM') || timeString.includes('PM')) {
        const isPM = timeString.includes('PM');
        const timePart = timeString.replace(/\s*(AM|PM)/, '').trim();
        
        if (timePart.includes(':')) {
            [hours, minutes] = timePart.split(':').map(Number);
        } else {
            hours = parseInt(timePart);
            minutes = 0;
        }
        
        if (isPM && hours < 12) hours += 12;
        if (!isPM && hours === 12) hours = 0;
    } else {
        // Default format: assume hours only
        hours = parseInt(timeString);
        minutes = 0;
    }
    
    return hours * 60 + minutes;
};

// ✅ Student Dashboard
const getStudentDashboard = async (req, res) => {
    try {
        const studentId = req.user.id;
        
        // Find student in database
        const student = await Student.findById(studentId);
        
        if (!student) {
            return res.status(404).render('errors/404', { 
                message: "Student not found",
                redirectUrl: "/auth/student"
            });
        }
        
        // Get registered courses count
        const registeredCoursesCount = student.courses.length;
        
        // Get available courses count
        const availableCoursesCount = await Course.countDocuments();
        
        // Render dashboard with student data
        res.render('student/dashboard', {
            student: student, 
            stats: {
                registeredCourses: registeredCoursesCount,
                availableCourses: availableCoursesCount
            }
        });
    } catch (error) {
        console.error("Dashboard Error:", error);
        res.status(500).render('errors/500', { 
            message: "Server error",
            redirectUrl: "/auth/student"
        });
    }
};

// ✅ Student Schedule
const getSchedule = async (req, res) => {
    try {
        const studentId = req.user.id;
        
        // Find student in database with populated courses
        const student = await Student.findById(studentId);
        
        if (!student) {
            return res.status(404).json({ 
                success: false, 
                message: "Student not found" 
            });
        }
        
        // Get full course details for each registered course
        const registeredCourses = [];
        
        for (const courseRef of student.courses) {
            const course = await Course.findById(courseRef.courseId);
            if (course) {
                registeredCourses.push({
                    id: course._id,
                    code: course.code,
                    name: course.name,
                    instructor: course.instructor,
                    days: course.days,
                    startTime: course.startTime,
                    endTime: course.endTime,
                    department: course.department
                });
            }
        }
        
        res.json({
            success: true,
            courses: registeredCourses
        });
    } catch (error) {
        console.error("Schedule Error:", error);
        res.status(500).json({ 
            success: false, 
            message: "Server error" 
        });
    }
};

// ✅ Fetch Available Courses
const getAvailableCourses = async (req, res) => {
    try {
        // Fetch all courses from database
        const courses = await Course.find({})
            .populate('prerequisites', 'code name');
        
        res.json({
            success: true,
            courses: courses
        });
    } catch (error) {
        console.error("Available Courses Error:", error);
        res.status(500).json({ 
            success: false, 
            message: "Server error" 
        });
    }
};

// ✅ Register for a Course
const registerCourse = async (req, res) => {
    try {
        const { courseId } = req.body;
        const studentId = req.user.id;
        
        // Find the course with prerequisites
        const course = await Course.findById(courseId).populate('prerequisites');
        if (!course) {
            return res.status(404).json({ success: false, message: 'Course not found' });
        }
        
        // Check if course has available seats
        if (course.availableSeats <= 0) {
            return res.status(400).json({ success: false, message: 'No available seats in this course' });
        }
        
        // Find the student
        const student = await Student.findById(studentId);
        if (!student) {
            return res.status(404).json({ success: false, message: 'Student not found' });
        }
        
        // Check if student is already registered for this course
        const alreadyRegistered = student.courses.some(c => c.courseId.toString() === courseId);
        if (alreadyRegistered) {
            return res.status(400).json({ success: false, message: 'Already registered for this course' });
        }
        
        // Check prerequisites
        if (course.prerequisites && course.prerequisites.length > 0) {
            const missingPrerequisites = [];
            
            for (const prereq of course.prerequisites) {
                const completed = student.completedCourses.some(
                    completedCourse => completedCourse.code === prereq.code
                );
                
                if (!completed) {
                    missingPrerequisites.push({
                        code: prereq.code,
                        name: prereq.name
                    });
                }
            }
            
            if (missingPrerequisites.length > 0) {
                const missingCourses = missingPrerequisites.map(p => `${p.code} (${p.name})`).join(', ');
                return res.status(400).json({ 
                    success: false, 
                    message: `Cannot register: Missing prerequisites: ${missingCourses}` 
                });
            }
        }
        
        // Add course to student's courses
        student.courses.push({
            courseId: course._id,
            code: course.code,
            name: course.name,
            department: course.department,
            instructor: course.instructor,
            days: course.days,
            startTime: course.startTime,
            endTime: course.endTime,
            credits: course.credits
        });
        
        // Update course available seats
        course.availableSeats -= 1;
        course.enrolled = (course.enrolled || 0) + 1;
        
        // Save changes
        await Promise.all([student.save(), course.save()]);
        
        // Emit seat update event
        const io = req.app.get('io');
        io.emit('seatUpdate', { courseId: course._id, availableSeats: course.availableSeats });
        
        return res.json({ 
            success: true, 
            message: 'Successfully registered for the course',
            course: {
                id: course._id,
                code: course.code,
                name: course.name,
                department: course.department,
                instructor: course.instructor,
                days: course.days,
                startTime: course.startTime,
                endTime: course.endTime,
                credits: course.credits
            }
        });
    } catch (error) {
        console.error('Error registering for course:', error);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

// ✅ Drop a Course
const dropCourse = async (req, res) => {
    try {
        const { courseId } = req.body;
        const studentId = req.user.id;
        
        // Find student in database
        const student = await Student.findById(studentId);
        
        if (!student) {
            return res.status(404).json({ 
                success: false, 
                message: "Student not found" 
            });
        }
        
        // Check if student is registered for the course
        const courseIndex = student.courses.findIndex(c => 
            c.courseId && c.courseId.toString() === courseId
        );
        
        if (courseIndex === -1) {
            return res.status(400).json({ 
                success: false, 
                message: "You are not registered for this course" 
            });
        }
        
        // Find the course in database
        const course = await Course.findById(courseId);
        
        // Remove course from student's courses
        student.courses.splice(courseIndex, 1);
        
        // Increase available seats in course if it exists
        if (course) {
            course.availableSeats += 1;
            await course.save();
        }
        
        // Save changes to student
        await student.save();
        
        // Get the io instance
        const io = req.app.get('io');
        
        // Emit real-time update to admin dashboard
        if (io) {
            io.to('admin-dashboard').emit('course-registration', {
                courseId: courseId,
                courseName: course ? course.name : "Unknown Course",
                studentId: studentId,
                studentName: student.name,
                action: 'dropped'
            });
        }
        
        res.json({
            success: true,
            message: "Successfully dropped the course"
        });
    } catch (error) {
        console.error("Drop Course Error:", error);
        res.status(500).json({ 
            success: false, 
            message: "Server error" 
        });
    }
};

// ✅ Filter Courses
const filterCourses = async (req, res) => {
    try {
        const { department, level, days, timeRange, search } = req.query;
        
        // Build filter object
        const filter = {};
        
        if (department) filter.department = department;
        if (level) filter.level = level;
        
        // Handle search query
        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: 'i' } },
                { code: { $regex: search, $options: 'i' } },
                { instructor: { $regex: search, $options: 'i' } }
            ];
        }
        
        // Fetch courses with basic filters
        let courses = await Course.find(filter).populate('prerequisites', 'code name');
        
        // Apply days filter if provided
        if (days) {
            const requestedDays = days.split(',');
            courses = courses.filter(course => 
                requestedDays.some(day => 
                    course.days.map(d => d.toLowerCase()).includes(day.toLowerCase())
                )
            );
        }
        
        // Apply time range filter if provided
        if (timeRange) {
            const [start, end] = timeRange.split('-');
            const startMinutes = parseTimeToMinutes(start);
            const endMinutes = parseTimeToMinutes(end);
            
            courses = courses.filter(course => {
                const courseStartMinutes = parseTimeToMinutes(course.startTime);
                const courseEndMinutes = parseTimeToMinutes(course.endTime);
                
                return courseStartMinutes >= startMinutes && courseEndMinutes <= endMinutes;
            });
        }
        
        res.json({
            success: true,
            courses: courses
        });
    } catch (error) {
        console.error("Filter Courses Error:", error);
        res.status(500).json({ 
            success: false, 
            message: "Server error" 
        });
    }
};

// ✅ Check Prerequisites
const checkPrerequisites = async (req, res) => {
    try {
        const { courseId } = req.body;
        const studentId = req.user.id;
        
        // Find the course with prerequisites
        const course = await Course.findById(courseId).populate('prerequisites');
        if (!course) {
            return res.status(404).json({ success: false, message: 'Course not found' });
        }
        
        // Find the student
        const student = await Student.findById(studentId);
        if (!student) {
            return res.status(404).json({ success: false, message: 'Student not found' });
        }
        
        // If no prerequisites, return success
        if (!course.prerequisites || course.prerequisites.length === 0) {
            return res.json({ 
                success: true, 
                message: 'No prerequisites required for this course' 
            });
        }
        
        // Check each prerequisite
        const missingPrerequisites = [];
        
        for (const prereq of course.prerequisites) {
            const completed = student.completedCourses.some(
                completedCourse => completedCourse.code === prereq.code
            );
            
            if (!completed) {
                missingPrerequisites.push({
                    code: prereq.code,
                    name: prereq.name
                });
            }
        }
        
        // If any prerequisites are missing, return error
        if (missingPrerequisites.length > 0) {
            const missingCourses = missingPrerequisites.map(p => `${p.code} (${p.name})`).join(', ');
            return res.status(400).json({ 
                success: false, 
                message: `Cannot register: Missing prerequisites: ${missingCourses}` 
            });
        }
        
        // All prerequisites are met
        return res.json({
            success: true,
            message: 'All prerequisites are met'
        });
    } catch (error) {
        console.error('Error checking prerequisites:', error);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};

module.exports = {
    getStudentDashboard,
    getSchedule,
    getAvailableCourses,
    registerCourse,
    dropCourse,
    filterCourses,
    checkPrerequisites
};
