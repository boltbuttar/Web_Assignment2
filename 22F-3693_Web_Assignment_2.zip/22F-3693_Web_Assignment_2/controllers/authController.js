const Student = require("../models/Student");
const Admin = require("../models/Admin");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

exports.studentLogin = async (req, res) => {
    try {
        const { rollNumber } = req.body;
        console.log("Student login attempt with roll number:", rollNumber);

        const student = await Student.findOne({ rollNumber });
        
        if (!student) {
            return res.status(401).json({ 
                success: false, 
                message: "Invalid roll number" 
            });
        }

        // Generate JWT token
        const token = jwt.sign(
            { id: student._id, role: "student" },
            process.env.JWT_SECRET || "your-secret-key",
            { expiresIn: "2h" }
        );

        // Send success response
        res.status(200).json({
            success: true,
            message: "Login successful",
            token,
            redirect: "/student/dashboard"
        });

    } catch (error) {
        console.error("Student login error:", error);
        res.status(500).json({ 
            success: false, 
            message: "An error occurred during login" 
        });
    }
};

exports.adminLogin = async (req, res) => {
    try {
        const { username, password } = req.body;
        console.log("Admin login attempt:", username);

        // For testing purposes - default admin
        if (username === "admin" && password === "admin123") {
            const token = jwt.sign(
                { id: "admin", role: "admin" },
                process.env.JWT_SECRET || "your-secret-key",
                { expiresIn: "2h" }
            );

            return res.status(200).json({
                success: true,
                message: "Login successful",
                token,
                redirect: "/admin/dashboard"
            });
        }

        // Find admin in database
        const admin = await Admin.findOne({ username });
        
        if (!admin || !(await bcrypt.compare(password, admin.password))) {
            return res.status(401).json({
                success: false,
                message: "Invalid credentials"
            });
        }

        const token = jwt.sign(
            { id: admin._id, role: "admin" },
            process.env.JWT_SECRET || "your-secret-key",
            { expiresIn: "2h" }
        );

        res.status(200).json({
            success: true,
            message: "Login successful",
            token,
            redirect: "/admin/dashboard"
        });

    } catch (error) {
        console.error("Admin login error:", error);
        res.status(500).json({
            success: false,
            message: "An error occurred during login"
        });
    }
};
