const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true }, // e.g., "CS101"
    department: { type: String, required: true }, // e.g., "Computer Science"
    level: { type: String, required: true }, // e.g., "Undergraduate"
    instructor: { type: String, required: true },
    schedule: {
        days: [String], // e.g., ["Monday", "Wednesday"]
        time: String // e.g., "10:00-11:30"
    },
    description: { type: String, default: "" },
    credits: { type: Number, default: 3 },
    capacity: { type: Number, required: true },
    availableSeats: { type: Number, required: true },
    enrolled: { type: Number, default: 0 },
    prerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: "Course" }], // References other courses
    createdAt: { type: Date, default: Date.now }
});

const Course = mongoose.model("Course", courseSchema);
module.exports = Course;
